#ifndef GRAFO_H
#define GRAFO_H

#define MAX 101
#define INF 1000000

void inicializaGrafo(int grafo[MAX][MAX], int n);
void lerGrafo(int grafo[MAX][MAX], int m, FILE *arquivo);

#endif
