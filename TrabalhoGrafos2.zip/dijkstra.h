#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#define MAX 101
#define INF 1000000

int dijkstra(int grafo[MAX][MAX], int n, int origem, int destino, int proibidas[MAX]);

#endif
